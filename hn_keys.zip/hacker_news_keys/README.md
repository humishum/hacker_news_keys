#  Hacker News Keys 
--- 
Chrome Extension to let you use Arrow Keys to browse Hacker News Comments. Free your hands from the shackles of your trackpad. 